<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of model
 *
 * @author Rohit Gilbile <rohitgilbile7@gmail.com>
 */
class Model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function auth($data) {
        $this->db->select('*');
        $this->db->from(USER);
        $this->db->where($data);
        $result = $this->db->get();
        return $result->result_array();
    }

    public function add($table, $data) {
        return $this->db->insert($table, $data);
    }

    public function select($table, $select, $where = null) {
        $this->db->select($select);
        $this->db->from($table);
        if ($where != NULL) {
            $this->db->where($where);
        }
        $result = $this->db->get();
        return $result->result_array();
    }

    public function selectJoin($select, $from, $where, $joinTable, $joinCondition) {
        $this->db->select($select)
                ->from($from)
                ->join($joinTable, $joinCondition)
                ->where($where);
        $result = $this->db->get();
        return $result->result_array();
    }

    public function selectJoin2($topic_id) {
        $role = 'student';
        $status = 'active';
        $result = $this->db->query("SELECT * FROM " . USER . ' where ' . USER . '.user_id not in (SELECT fk_user_id FROM ' . ASSIGN . " where fk_topic_id = " . $topic_id . ") AND role= '" . $role . "' AND user_status = '" . $status . "'");
        return $result->result_array();
    }

    public function update($table, $data, $where) {
        $result = $this->db->update($table, $data, $where);
        if ($result) {
            return true;
        } else {
            return false;
        }
    }

    public function delete($table, $data) {
        $result = $this->db->delete($table, $data);  // Produces: // DELETE FROM mytable  // WHERE id = $id
        if ($result) {
            return true;
        } else {
            return false;
        }
    }

    public function submitedTask() {
        $joinCondition = TOPIC_SUBMIT . '.submit_user_id = ' . USER . '.user_id';
        $joinCondition2 = TOPIC_SUBMIT . '.submit_topic_id = ' . TOPICS . '.pk_topic_id';
        $joinCondition3 = TOPIC_SUBMIT . '.submit_assign_id = ' . ASSIGN . '.assign_id';
        $this->db->select('*')
                ->from(TOPIC_SUBMIT)
                ->join(USER, $joinCondition)
                ->join(TOPICS, $joinCondition2)
                ->join(ASSIGN, $joinCondition3);
        $result = $this->db->get();

        return $result->result_array();
    }
    public function assignTopicList(){
         $joinCondition = USER . '.user_id = ' . ASSIGN . '.fk_user_id';
        $joinCondition2 = TOPICS . '.pk_topic_id = ' . ASSIGN . '.fk_topic_id';
        $this->db->select('*')
                ->from(ASSIGN)
                ->join(USER, $joinCondition)
                ->join(TOPICS, $joinCondition2);
        $result = $this->db->get();
        return $result->result_array();
    
    }

}

?>
