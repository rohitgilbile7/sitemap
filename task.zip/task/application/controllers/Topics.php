<?php

/**
 * Description of topics
 *
 * @author Rohit Gilbile <rohitgilbile7@gmail.com>
 */
class Topics extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Model');
    }

    public function index() {
        $result['data'] = $this->Model->select(TOPICS, '*');
        $this->load->view('allTopics', $result);
    }

    public function all() {
        $result['data'] = $this->Model->select(TOPICS, '*');
        $this->load->view('allTopics', $result);
    }

    public function add() {
        $this->form_validation->set_rules('topicTitle', 'Title', 'required');
        $this->form_validation->set_rules('topicDesc', 'Description', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('addTopics');
        } else {
            $topicTitle = $this->input->post('topicTitle');
            $topicDesc = $this->input->post('topicDesc');
            $topicStatus = $this->input->post('topicStatus');
            $data = array('title' => $topicTitle, 'description' => $topicDesc, 'status' => $topicStatus);
            $result = $this->Model->add(TOPICS, $data);
            if ($result) {
                redirect('topics/all');
            } else {
                $data['message'] = 'Failed to add new topics !';
                $this->load->view('addTopics');
            }
        }
    }

    public function edit($id) {

        if (!is_numeric($id)) {
            $data['message'] = 'Topic not found to edit';
            $this->load->view('404', $data);
        }
        $data = array('topic_id' => $id);
        $result['data'] = $this->Model->select(TOPICS, '*', $data);
        $this->load->view('editTopics', $result);
    }

    public function update() {
        $this->form_validation->set_rules('topicTitle', 'Title', 'required');
        $this->form_validation->set_rules('topicDesc', 'Description', 'required');
        $id = $this->input->post('id');
        if (empty($id)) {
            redirect('topics/all');
        }
        if ($this->form_validation->run() == FALSE) {
            $data = array('topic_id' => $id);
            $result['data'] = $this->Model->select(TOPICS, '*', $data);
            $this->load->view('editTopics', $result);
        } else {
            // Check Topic exists or is active to update
            $datas = array('topic_id' => $id, 'status' => 'active');
            $result = $this->Model->select(TOPICS, '*', $datas);
            if (empty($result)) {
                $data['message'] = 'Topic not found';
                $this->load->view('404', $data);
            } else {
                $topicTitle = $this->input->post('topicTitle');
                $topicDesc = $this->input->post('topicDesc');
                $topicStatus = $this->input->post('topicStatus');
                $data = array('title' => $topicTitle, 'description' => $topicDesc, 'status' => $topicStatus);
                $where = array('topic_id' => $id);
                $result = $this->Model->update(TOPICS, $data, $where);
                if ($result) {
                    $response['status'] = 'success';
                    $response['message'] = 'Record updated successfully !';
                    $response['data'] = $this->Model->select(TOPICS, '*');
                    $this->load->view('allTopics', $response);
                } else {
                    $data['message'] = 'Failed to add new topics !';
                    $this->load->view('addTopics');
                }
            }
        }
    }

    public function delete($id) {
        $data = array('topic_id' => $id, 'status' => 'active');
        $result = $this->Model->select(TOPICS, '*', $data);
        if (empty($result)) {
            redirect('topics/all');
        }
        $result = $this->Model->delete(TOPICS, $data);
        if ($result) {
            $response['status'] = 'success';
            $response['message'] = 'Record deleted successfully !';
            $response['data'] = $this->Model->select(TOPICS, '*');
            $this->load->view('allTopics', $response);
        } else {
            $response['status'] = 'failure';
            $response['message'] = 'Failed to delete record !';
            $response['data'] = $this->Model->select(TOPICS, '*');
            $this->load->view('allTopics', $response);
        }
    }

    public function assigntopic($id) {
        if (!empty($id) && is_numeric($id)) {
            $where = array('pk_topic_id' => $id, 'status' => 'active');
            $data['topics'] = $this->Model->select(TOPICS, '*', $where);
            if (empty($data)) {
                $data['message'] = 'Topic not found';
                $this->load->view('404', $data);
            } else {
                $data['data'] = $this->Model->selectJoin2($id);
                $data['topic_id'] = $id;
                $this->load->view('assignTopic', $data);
            }
        } else {
            $this->session->set_flashdata('404_message', 'Record Not Found');
            $this->load->view('404');
        }
    }

    public function assign() {
        $students = $this->input->post('students');
        $topic_id = $this->input->post('topic_id');
        if (empty($students) || count($students) == 0) {
            $select = '*';
            $from = USER;
            $where = array('role' => 'student', 'user_status' => 'active');
            $joinTable = ASSIGN;
             $joinCondition = USER.'.user_id !=' . ASSIGN.'.fk_user_id';
            // $joinTable2 = TOPIC;
            $joinCondition2 = TOPIC . '.topic_id != ' . ASSIGN . '.fk_topic_id';
            $result['data'] = $this->Model->selectJoin($select, $from, $where, $joinTable, $joinCondition);
            $result['message'] = 'Please select students';
            $this->load->view('assignTopic', $result);
        } else {
            foreach ($students as $key) {
                $data = array('fk_topic_id' => $topic_id, 'fk_user_id' => $key, 'assign_status' => 'assign');
//                $Assignwhere = array('')
                $row = $this->Model->select(ASSIGN, '*', $data);
                if ((count($row) <= 0) || empty($row)) {
                    $this->Model->add(ASSIGN, $data);
                }
            }
            $this->session->set_flashdata('success_message', 'Topic assign successfully!');
            $result['data'] = $this->Model->select(TOPICS, '*');
            $this->load->view('allTopics', $result);
        }
    }

    public function student() {
        $result['data'] = $this->Model->submitedTask();
//        echo '<pre>';print_r($result);die;
        $this->load->view('studentSubmitTopic', $result);
    }

    public function changestatus($id) {
        if ((!empty($id)) && (is_numeric($id))) {
            $where = array('pk_submit_id' => $id);
            $data['topics'] = $this->Model->select(TOPIC_SUBMIT, '*', $where);
            if (empty($data['topics'])) {
                $data['message'] = 'Topic not found';
                $this->load->view('404', $data);
            } else {
                $result['data'] = $this->Model->submitedTask();
                $this->load->view('changeStatus', $result);
            }
        }
    }

    public function updatestatus() {
        $pk_submit_id = $this->input->post('pk_submit_id');
        $assign_id = $this->input->post('assign_id');
        $topicStatus = $this->input->post('topicStatus');
        $data = array('submit_status' => $topicStatus);
        $where = array('pk_submit_id' => $pk_submit_id);
        $result = $this->Model->update(TOPIC_SUBMIT, $data, $where);
        $data2 = array('assign_status' => $topicStatus);
        $where2 = array('assign_id' => $assign_id);
        $result = $this->Model->update(ASSIGN, $data2, $where2);
        $this->session->set_flashdata('success_message', 'Status Change Successfully!');

        redirect('topics/student');
    }
    public function assigntopiclist(){
        $result['data'] = $this->Model->assignTopicList();
        $this->load->view('assignList',$result);
    }
}

?>
