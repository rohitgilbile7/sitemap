<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Model');
        if ($this->session->has_userdata('user_data')) {
            redirect('dashboard');
        }
    }

    public function index() {
        $this->load->view('login');
    }

    public function auth() {
        $this->form_validation->set_rules('email', 'Email', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('login');
        } else {
            $email = $this->input->post('email');
            $password = $this->input->post('password');
            $data = array('email' => $email, 'password' => md5($password));
            $result = $this->Model->auth($data);
            if ($result) {
                $this->session->set_userdata('user_data', $result);
                $this->session->set_userdata('profile_pic', $result[0]['profile_pic']);

                redirect('dashboard');
            } else {
                $data['message'] = 'email or password is wrong !';
                $this->load->view('login', $data);
            }
        }
    }

}

?>
