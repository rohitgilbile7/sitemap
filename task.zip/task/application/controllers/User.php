<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of User 
 *
 * @author Rohit Gilbile <rohitgilbile7@gmail.com>
 */
class User extends CI_Controller {

    //put your code here
    public function __construct() {
        parent::__construct();
        if (!$this->session->has_userdata('user_data')) {
            redirect('login');
        }
        $this->user_data = $this->session->userdata('user_data');
        $this->id = $this->user_data[0]['user_id'];

        $this->load->model('Model');
    }

    public function index() {
        $this->load->view('userAdd');
    }

    public function assigntopic() {
        $select = '*';
        $from = ASSIGN;
        $where = array('fk_user_id' => $this->id);
        $joinTable = TOPICS;
        $joinCondition = ASSIGN . '.fk_topic_id = ' . TOPICS . '.pk_topic_id';
        $data['data'] = $this->Model->selectJoin($select, $from, $where, $joinTable, $joinCondition);
        $this->load->view('userAssign', $data);
    }

    public function addtopic($id) {
        if (is_numeric($id)) {
            $select = '*';
            $from = ASSIGN;
            $where = array('fk_topic_id' => $id, 'fk_user_id' => $this->id);
            $joinTable = TOPICS;
            $joinCondition = ASSIGN . '.fk_topic_id = ' . TOPICS . '.pk_topic_id';
            $data['data'] = $this->Model->selectJoin($select, $from, $where, $joinTable, $joinCondition);
            $errors = array_filter($data);
            if ((!isset($data['data'])) || (empty($errors))) {
                $data['message'] = 'Topic not found';
                $this->load->view('404', $data);
            } else {
                $data['topic_id'] = $id;
//                echo '<pre>';print_r($data);die;
                $this->load->view('userAddTopic', $data);
            }
        } else {
            $data['message'] = 'Topic not found!';
            $this->load->view('404', $data);
        }
    }

    public function submittopic() {
        $assign_id = $this->input->post('assign_id');
        $fk_topic_id = $this->input->post('fk_topic_id');
        $fk_user_id = $this->input->post('fk_user_id');
        $this->form_validation->set_rules('topicDesc', 'Description', 'required');
        if (empty($_POST)) {
            redirect('user/assigntopic');
        }
        if ($this->form_validation->run() == FALSE) {
            $select = '*';
            $from = ASSIGN;
            $where = array('fk_topic_id' => $fk_topic_id, 'fk_user_id' => $this->id, ASSIGN . '.assign_status' => 'assign');
            $joinTable = TOPICS;
            $joinCondition = ASSIGN . '.fk_topic_id = ' . TOPICS . '.pk_topic_id';
            $data['data'] = $this->Model->selectJoin($select, $from, $where, $joinTable, $joinCondition);
            $data['topic_id'] = $fk_topic_id;
            $data['fk_user_id'] = $fk_user_id;
            $data['assign_id'] = $assign_id;
            $this->load->view('userAddTopic', $data);
        } else {
            $title = $this->input->post('topicTitle');
            $description = $this->input->post('topicDesc');
            // check topic exists
            $Submitwhere = array('submit_assign_id' => $assign_id, 'submit_topic_id' => $fk_topic_id, 'submit_user_id' => $fk_user_id);
            $row = $this->Model->select(TOPIC_SUBMIT, '*', $Submitwhere);
            if (!empty($row)) {
                $updatedata = array('submit_status' => 'pending', 'submit_title' => $title, 'submit_desc' => $description);
                $where = array('submit_assign_id' => $assign_id);
                $r = $this->Model->update(TOPIC_SUBMIT, $updatedata, $where);
            } else {
                $data = array('submit_assign_id' => $assign_id, 'submit_topic_id' => $fk_topic_id, 'submit_user_id' => $fk_user_id, 'submit_title' => $title, 'submit_desc' => $description, 'submit_status' => 'pending');
                $result = $this->Model->add(TOPIC_SUBMIT, $data);
            }
            //end

            $updatedata = array('assign_status' => 'pending');
            $where = array('assign_id' => $assign_id);
            $r = $this->Model->update(ASSIGN, $updatedata, $where);
            $this->session->set_flashdata('success_message', 'Topic submit successfully!');
            $select = '*';
            $from = ASSIGN;
            $where = array('fk_user_id' => $this->id);
            $joinTable = TOPICS;
            $joinCondition = ASSIGN . '.fk_topic_id = ' . TOPICS . '.pk_topic_id';
            $data['data'] = $this->Model->selectJoin($select, $from, $where, $joinTable, $joinCondition);
            $this->load->view('userAssign', $data);
        }
    }

    public function add() {
        $this->form_validation->set_rules('fullname', 'Full Name', 'required');
        $this->form_validation->set_rules('email', 'email', 'required|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('cpassword', 'Confirm password', 'required|matches[password]');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('userAdd');
        } else {
            // File upload
            if (isset($_FILES['file']) && is_uploaded_file($_FILES['file']['tmp_name'])) {

                $config['upload_path'] = './uploads/';
                $config['allowed_types'] = 'jpg|png';
                $config['max_size'] = 100;
//                $config['max_width'] = 1024;
//                $config['max_height'] = 768;

                $this->load->library('upload', $config);

                if (!$this->upload->do_upload('file')) {
                    $error = array('error' => $this->upload->display_errors());
                    $this->load->view('userAdd', $error);
                } else {
                    $full_name = $this->input->post('fullname');
                    $email = $this->input->post('email');
                    $password = md5($this->input->post('password'));
                    $data = $this->upload->data();
                    $file = $data['file_name'];
                    $data = array('full_name' => $full_name, 'email' => $email, 'password' => $password, 'profile_pic' => $file, 'role' => 'student', 'user_status' => 'active');
                    $result = $this->Model->add(USER, $data);
                    if ($result) {
                        $this->session->set_flashdata('success_message', 'User created successfully !');
                    } else {
                        $this->session->set_flashdata('error_message', 'Please try again');
                    }
                    $this->load->view('userAdd');
                }
            }
        }
    }

    public function signup() {
        $this->load->view('userAdd');
    }

    public function profile() {
        $this->load->view('userProfile');
    }

    public function updateprofile() {
        if (isset($_FILES['file']) && is_uploaded_file($_FILES['file']['tmp_name'])) {

            $config['upload_path'] = './uploads/';
            $config['allowed_types'] = 'jpg|png';
            $config['max_size'] = 100;
//                $config['max_width'] = 1024;
//                $config['max_height'] = 768;

            $this->load->library('upload', $config);

            if (!$this->upload->do_upload('file')) {
                $error = array('error' => $this->upload->display_errors());
                $this->load->view('userProfile', $error);
            } else {
                $user_data = $this->session->userdata('user_data');
                $id = $user_data[0]['user_id'];
                $data = $this->upload->data();
                $file = $data['file_name'];
                $data = array('profile_pic' => $file);
                $where = array('user_id' => $id);
                $result = $this->Model->update(USER, $data, $where);
              //  $result = $this->Model->add(USER, $data);
                if ($result) {
                    $sessionData = array('profile_pic' =>$file);

                    $this->session->set_userdata('profile_pic',$file);
                    $user_data = $this->session->userdata('profile_pic');

                    $this->session->set_flashdata('success_message', 'Profile updated successfully !');
                } else {
                    $this->session->set_flashdata('error_message', 'Please try again');
                }
            }
        }
                        $this->load->view('userProfile');

    }
    public function students(){
        $where = array('role'=>'student');
       $result['data']  = $this->Model->select(USER,'*',$where);
       $this->load->view('studentList',$result);
    }

}

?>
