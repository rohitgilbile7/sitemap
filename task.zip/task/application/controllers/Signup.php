<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of signup
 *
 * @author Rohit Gilbile <rohitgilbile7@gmail.com>
 */
class Signup extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Model');
    }

    public function index() {
        $this->load->view('signup');
    }

    public function join() {
        $this->form_validation->set_rules('fullname', 'Full Name', 'required');
        $this->form_validation->set_rules('email', 'email', 'required|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('cpassword', 'Confirm password', 'required|matches[password]');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('signup');
        } else {
            // File upload
            if (isset($_FILES['file']) && is_uploaded_file($_FILES['file']['tmp_name'])) {

                $config['upload_path'] = './uploads/';
                $config['allowed_types'] = 'jpg|png';
                $config['max_size'] = 100;
//                $config['max_width'] = 1024;
//                $config['max_height'] = 768;

                $this->load->library('upload', $config);

                if (!$this->upload->do_upload('file')) {
                    $error = array('error' => $this->upload->display_errors());

                    $this->load->view('signup', $error);
                }
            }
        }
    }

}

?>
