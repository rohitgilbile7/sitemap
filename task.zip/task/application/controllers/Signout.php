<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Signout 
 *
 * @author Rohit Gilbile <rohitgilbile7@gmail.com>
 */
class Signout extends CI_Controller {

    //put your code here
    public function __construct() {
        parent::__construct();
    }

    public function index() {
        if ($this->session->has_userdata('user_data')) {
            $this->session->unset_userdata('user_data');
        }
        redirect('login');
    }

}

?>
