<?php
/**
 * Description of allTopics
 *
 * @author Rohit Gilbile <rohitgilbile7@gmail.com>
 */
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
        <?php include 'include/head.php'; ?>

    </head>
    <body class="hold-transition skin-blue sidebar-mini">
        <div class="wrapper">
            <?php include 'include/header.php'; ?>
            <?php include 'include/aside.php'; ?>
            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Main content -->
                <section class="content">
                    <div class="row">
                        <div class="col-xs-12">

                            <div class="box">
                                <div class="box-header">
                                    <h3 class="box-title">Assign Topics List</h3>
                                </div>
                                <?php
                                if ($this->session->flashdata('success_message')) {
                                    ?>
                                    <div class="alert alert-success alert-dismissible">
                                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                        <h4><i class="icon fa fa-check"></i> Alert!</h4>
                                        <?php echo $this->session->flashdata('success_message'); ?>
                                    </div>
                                    <?php
                                }
                                if (isset($message)) {
                                    if ($status == 'success') {
                                        ?>
                                        <div class="alert alert-success alert-dismissible">
                                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                            <h4><i class="icon fa fa-check"></i> Alert!</h4>
                                            <?php echo $message; ?>
                                        </div>
                                        <?php
                                    }
                                    if ($status == 'failure') {
                                        ?>
                                        <div class="alert alert-danger alert-dismissible">
                                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                            <h4><i class="icon fa fa-ban"></i> Alert!</h4>
                                            <?php echo $message; ?>
                                        </div>
                                        <?php
                                    }
                                }
                                ?>
                                <!-- /.box-header -->
                                <div class="box-body">
                                    <table id="example1" class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th>Title</th>
                                                <th>Description</th>
                                                <th>Status</th>
                                                <th>Assign</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            foreach ($data as $key) {
                                                ?>
                                                <tr>
                                                    <td><?php echo $key['title']; ?></td>
                                                    <td><?php echo $key['description']; ?></td>
                                                    <td><?php echo $key['assign_status']; ?></td>
                                                    <td>
                                                        <?php
                                                        if (($key['assign_status'] == 'assign') || ($key['assign_status'] == 'reopen')) {
                                                            ?><a href="<?php echo base_url('index.php/user/addtopic/' . $key['pk_topic_id']); ?>">Submit</a> <?php
                                                        } else if ($key['assign_status'] == 'completed') {
                                                            ?><a href="javascript:void(0)">Completed</a> <?php
                                                        } else if ($key['assign_status'] == 'pending') {
                                                            ?><a href="javascript:void(0)">Pending</a> <?php
                                                        } else {
                                                            echo 'No Result';
                                                        }
                                                        ?></td>
                                                </tr>
                                                        <?php
                                                    }
                                                    ?>

                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>Title</th>
                                                <th>Description</th>
                                                <th>Status</th>
                                                <th>Assign</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                                <!-- /.box-body -->
                            </div>
                            <!-- /.box -->
                        </div>
                        <!-- /.col -->
                    </div>
                    <!-- /.row -->
                </section>
                <!-- /.content -->
            </div>
            <!-- /.content-wrapper -->
<?php include 'include/footer.php' ?>;

            <div class="control-sidebar-bg"></div>

        </div>

        <!-- jQuery 2.2.3 -->
        <script src="<?php echo base_url(); ?>plugins/jQuery/jquery-2.2.3.min.js"></script>
        <!-- Bootstrap 3.3.6 -->
        <script src="<?php echo base_url(); ?>bootstrap/js/bootstrap.min.js"></script>
        <!-- DataTables -->
        <script src="<?php echo base_url(); ?>plugins/datatables/jquery.dataTables.min.js"></script>
        <script src="<?php echo base_url(); ?>plugins/datatables/dataTables.bootstrap.min.js"></script>
        <!-- SlimScroll -->
        <script src="<?php echo base_url(); ?>plugins/slimScroll/jquery.slimscroll.min.js"></script>
        <!-- FastClick -->
        <script src="<?php echo base_url(); ?>plugins/fastclick/fastclick.js"></script>
        <!-- AdminLTE App -->
        <script src="<?php echo base_url(); ?>dist/js/app.min.js"></script>
        <!-- AdminLTE for demo purposes -->
        <script src="<?php echo base_url(); ?>dist/js/demo.js"></script>
        <!-- page script -->
        <script>
            $(function() {
                $("#example1").DataTable();

                $('#example2').DataTable({
                    "paging": true,
                    "lengthChange": false,
                    "searching": false,
                    "ordering": true,
                    "info": true,
                    "autoWidth": false
                });
            });

            function doconfirm()
            {
                job = confirm("Are you sure to delete permanently?");
                if (job != true)
                {
                    return false;
                }
            }
        </script>
    </body>
</html>
