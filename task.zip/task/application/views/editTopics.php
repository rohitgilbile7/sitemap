<?php
/**
 * Description of allTopics 
 *
 * @author Rohit Gilbile <rohitgilbile7@gmail.com>
 */
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
        <?php include 'include/head.php'; ?>

    </head>
    <body class="hold-transition skin-blue sidebar-mini">
        <div class="wrapper">
            <?php include 'include/header.php'; ?>
            <?php include 'include/aside.php'; ?>
            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                        Topics
                        <small>Edit</small>
                    </h1>
                    <ol class="breadcrumb">
                        <li><a href="<?php echo base_url(); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                        <li><a href="<?php echo base_url('index.php/topics'); ?>">Topics</a></li>
                        <li class="active">Edit</li>
                    </ol>
                </section>

                <!-- Main content -->
                <section class="content">
                    <div class="row">
                        <!-- left column -->
                        <div class="col-md-10">
                            <!-- general form elements -->
                            <div class="box box-primary">
                                <div class="box-header with-border">
                                    <h3 class="box-title">Edit Topics</h3>
                                </div>
                                <!-- /.box-header -->
                                <?php
                                foreach ($data as $key) {
                                    $id = $key['topic_id'];
                                    $title = $key['title'];
                                    $description = $key['description'];
                                    $status = $key['status'];
                                }
                                ?>
                                <!-- form start -->
                                <form role="form" method="POST" action="<?php echo base_url('index.php/topics/update'); ?>">
                                    <div class="box-body">
                                        <span class="error-content err ">  <?php
                                            if (!empty($message)) {
                                                echo $message;
                                            }
                                            ?>
                                    <?php echo validation_errors(); ?></span>
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Topic Title</label>
                                            <input type="hidden" name="id" value="<?php echo $id; ?>" />                                                
                                            <input type="text" class="form-control" required="" value="<?php echo $title; ?>" name="topicTitle" id="exampleInputEmail1" placeholder="Enter topic title">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Description</label>
                                            <textarea rows="5" cols="3"  class="form-control" required="" name="topicDesc" id="exampleInputPassword1" > <?php echo $description; ?></textarea>
                                        </div>
                                        <div class="form-group">
                                            <div class="form-group">
                                                <label>Status</label>
                                                <select class="form-control" name="topicStatus">
                                                    <option value="<?php echo $status;?>" selected=""><?php echo $status; ?></option>
                                                    <?php if($status != 'active'){ ?>
                                                    <option value="active">Active</option>
                                                    <?php } else{ ?>
                                                    <option value="pending">Pending</option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>   

                                    </div>
                                    <!-- /.box-body -->

                                    <div class="box-footer">
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                    </div>
                                </form>
                            </div>
                            <!-- /.box -->

                        </div>
                        <!--/.col (left) -->

                    </div>
                    <!-- /.row -->
                </section>
                <!-- /.content -->
            </div>
            <!-- /.content-wrapper -->


        </div>  
         <!-- jQuery 2.2.3 -->
        <script src="<?php echo base_url(); ?>plugins/jQuery/jquery-2.2.3.min.js"></script>
        <!-- Bootstrap 3.3.6 -->
        <script src="<?php echo base_url(); ?>bootstrap/js/bootstrap.min.js"></script>
        <!-- DataTables -->
        <script src="<?php echo base_url(); ?>plugins/datatables/jquery.dataTables.min.js"></script>
        <script src="<?php echo base_url(); ?>plugins/datatables/dataTables.bootstrap.min.js"></script>
        <!-- SlimScroll -->
        <script src="<?php echo base_url(); ?>plugins/slimScroll/jquery.slimscroll.min.js"></script>
        <!-- FastClick -->
        <script src="<?php echo base_url(); ?>plugins/fastclick/fastclick.js"></script>
        <!-- AdminLTE App -->
        <script src="<?php echo base_url(); ?>dist/js/app.min.js"></script>
        <!-- AdminLTE for demo purposes -->
        <script src="<?php echo base_url(); ?>dist/js/demo.js"></script>
        <!-- page script -->
       
    </body>
</html>
