
<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->
        <div class="user-panel">
            <div class="pull-left image">
                <?php
                if (empty($profile_pic)) {
                    ?>
                    <img src="<?php echo base_url(); ?>dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
                <?php } else { ?>
                    <img src="<?php echo base_url(); ?>uploads/<?php echo $profile_pic; ?>" height="160" width="160" class="img-circle" alt="User Image">

                <?php } ?>
            </div>
            <div class="pull-left info">
                <p><?php echo $full_name; ?></p>
                <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
        </div>
        <!-- search form -->

        <!-- /.search form -->
        <!-- sidebar menu: : style can be found in sidebar.less -->
        <?php $user_data = $this->session->userdata('user_data'); ?>

        <ul class="sidebar-menu">
            <li class="header">MAIN NAVIGATION</li>
            <?php
            if ($user_data[0]['role'] == 'admin') {
                ?>
                <li><a href="<?php echo base_url('dashboard'); ?>"><i class="fa fa-book"></i> <span>Dashboard</span></a></li>
                <li><a href="<?php echo base_url('user/students'); ?>"><i class="fa fa-book"></i> <span>Student List</span></a></li>

                <li><a href="<?php echo base_url('user/signup'); ?>"><i class="fa fa-book"></i> <span>Add Student</span></a></li>
                <li><a href="<?php echo base_url('index.php/topics/add'); ?>"><i class="fa  fa-pencil-square-o"></i> Add Topics</a></li>
                <li><a href="<?php echo base_url('index.php/topics/all'); ?>"><i class="fa  fa-list-alt"></i>Topics List</a></li>
                <li><a href="<?php echo base_url('index.php/topics/assigntopiclist'); ?>"><i class="fa  fa-list-alt"></i>Assign Topics List</a></li>
                <li><a href="<?php echo base_url('index.php/topics/student'); ?>"><i class="fa  fa-list-alt"></i>Student submitted topic</a></li>
                <?php
            }
            if ($user_data[0]['role'] == 'student') {
                ?>
                <li><a href="<?php echo base_url('dashboard'); ?>"><i class="fa fa-book"></i> <span>Dashboard</span></a></li>

                <li class="">
                    <a href="<?php echo base_url('index.php/user/assigntopic'); ?>">
                        <i class="fa  fa-laptop"></i> <span>Assign Topics</span>
                    </a>

                </li>
                <?php
            }
            ?>
        </ul>
    </section>
    <!-- /.sidebar -->
</aside>
