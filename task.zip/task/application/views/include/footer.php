<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 2.3.8
    </div>
    <strong>Copyright &copy; 2014-2016 <a href="http://github.com/rohitgilbile7">Rohit Gibile</a>.</strong> All rights
    reserved.
  </footer>
