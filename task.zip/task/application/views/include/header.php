<?php
$user_data = $this->session->userdata('user_data');
$id = $user_data[0]['user_id'];
$full_name = $user_data[0]['full_name'];
$profile_pic = $user_data[0]['profile_pic'];
$email = $user_data[0]['email'];
//$result[0]['profile_pic']
 $profile_pic = $this->session->userdata('profile_pic');

?>
<header class="main-header">
    <!-- Logo -->
    <a href="<?php echo base_url(); ?>" class="logo">
        <!-- mini logo for sidebar mini 50x50 pixels -->
        <span class="logo-mini"><b>A</b>P</span>
        <!-- logo for regular state and mobile devices -->
        <span class="logo-lg"><b>Admin</b>Panel</span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
        <!-- Sidebar toggle button-->
        <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
        </a>

        <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
                <!-- Messages: style can be found in dropdown.less-->

                <!-- Notifications: style can be found in dropdown.less -->

                <!-- Tasks: style can be found in dropdown.less -->

                <!-- User Account: style can be found in dropdown.less -->
                <li class="dropdown user user-menu">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <?php
                        if (empty($profile_pic)) {
                            ?>
                            <img src="<?php echo base_url(); ?>dist/img/user2-160x160.jpg" class="user-image" alt="User Image">
                        <?php } else { ?>
                            <img src="<?php echo base_url(); ?>uploads/<?php echo $profile_pic; ?>" height="160" width="160" class="img-circle" alt="User Image">

                        <?php } ?>
                        <span class="hidden-xs"> <?php echo $full_name; ?> </span>
                    </a>
                    <ul class="dropdown-menu">
                        <!-- User image -->
                        <li class="user-header">
                            <?php
                            if (empty($profile_pic)) {
                                ?>
                                <img src="<?php echo base_url(); ?>dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
                            <?php } else { ?>
                                <img src="<?php echo base_url(); ?>uploads/<?php echo $profile_pic; ?>" height="160" width="160" class="img-circle" alt="User Image">

                            <?php } ?>
                            <p>
                                <?php echo $full_name; ?>
                            </p>
                        </li>
                        <!-- Menu Body -->

                        <!-- Menu Footer-->
                        <li class="user-footer">
                            <div class="pull-left">
                                <a href="<?php echo base_url('user/profile'); ?>" class="btn btn-default btn-flat">Profile</a>
                            </div>
                            <div class="pull-right">
                                <a href="<?php echo base_url('index.php/signout'); ?>" class="btn btn-default btn-flat">Sign out</a>
                            </div>
                        </li>
                    </ul>
                </li>
                <!-- Control Sidebar Toggle Button -->
                
            </ul>
        </div>
    </nav>
</header>
