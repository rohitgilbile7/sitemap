<?php
/**
 * Description of allTopics
 *
 * @author Rohit Gilbile <rohitgilbile7@gmail.com>
 */
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
        <?php include 'include/head.php'; ?>
        <link rel="stylesheet" href="<?php echo base_url();?>plugins/select2/select2.min.css">

    </head>
    <body class="hold-transition skin-blue sidebar-mini">
        <div class="wrapper">
            <?php include 'include/header.php'; ?>
            <?php include 'include/aside.php'; ?>
            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                        Topics
                        <small>Assign</small>
                    </h1>
                    <ol class="breadcrumb">
                        <li><a href="<?php echo base_url(); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                        <li><a href="<?php echo base_url('index.php/topics'); ?>">Topics</a></li>
                        <li class="active">Assign</li>
                    </ol>
                </section>
                <!-- Main content -->
                <section class="content">
                    <div class="row">
                        <!-- left column -->
                        <div class="col-md-10">
                            <!-- general form elements -->
                            <div class="box box-primary">
                                <div class="box-header with-border">
                                    <h3 class="box-title">Assign Topic <?php if(isset($topics[0]['title'])){echo ': '. $topics[0]['title']; }?></h3>
                                </div>
                                <!-- /.box-header -->
                                 <?php if (!empty($message)) { echo $message; } ?>
                                <?php
                                if ($this->session->flashdata('success_message')) {
                                    ?>
                                    <div class="alert alert-success alert-dismissible">
                                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                        <h4><i class="icon fa fa-check"></i> Alert!</h4>
                                        <?php echo $this->session->flashdata('success_message'); ?>
                                    </div>
                                    <?php
                                }
                                if ($this->session->flashdata('error_message')) {
                                    ?>
                                    <div class="alert alert-danger alert-dismissible">
                                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                        <h4><i class="icon fa fa-ban"></i> Alert!</h4>
                                        <?php echo $this->session->flashdata('error_message'); ?>
                                    </div>
                                    <?php
                                }
                                ?>
                                <!-- form start -->
                                  <?php echo form_open('topics/assign'); ?>
                                <form role="form" method="POST">
                                    <div class="box-body">
                                      <input type="hidden" name="topic_id" value="<?php echo $topic_id; ?>" />
                                           <div class="form-group">
                                             <label>Select Students</label>
                                             <select name="students[]" class="form-control select2" multiple="multiple" data-placeholder="Select a Student" style="width: 100%;">
                                               <?php
                                              foreach ($data as $key) {
                                                  ?>
                                                  <option value="<?php echo $key['user_id']; ?>"> <?php echo $key['full_name']; ?></option>
                                                  <?php
                                                }
                                                ?>
                                             </select>
                                      </div>
                                    <!-- /.box-body -->
                                    <div class="box-footer">
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                    </div>
                                </form>
                            </div>
                            <!-- /.box -->

                        </div>
                        <!--/.col (left) -->

                    </div>
                    <!-- /.row -->
                </section>
                <!-- /.content -->
            </div>
            <!-- /.content-wrapper -->


        </div>

        <!-- jQuery 2.2.3 -->
        <script src="<?php echo base_url();?>plugins/jQuery/jquery-2.2.3.min.js"></script>
        <!-- Bootstrap 3.3.7 -->
        <script src="<?php echo base_url();?>bootstrap/js/bootstrap.min.js"></script>
        <!-- Select2 -->
        <script src="<?php echo base_url();?>plugins/select2/select2.full.min.js"></script>

        <script>
          $(function () {
            //Initialize Select2 Elements
            $(".select2").select2();
          });
        </script>
    </body>
</html>
