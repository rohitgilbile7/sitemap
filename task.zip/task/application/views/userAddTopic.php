<?php
/**
 * Description of allTopics 
 *
 * @author Rohit Gilbile <rohitgilbile7@gmail.com>
 */
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
        <?php include 'include/head.php'; ?>

    </head>
    <body class="hold-transition skin-blue sidebar-mini">
        <div class="wrapper">
            <?php include 'include/header.php'; ?>
            <?php include 'include/aside.php'; ?>
            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                        Topics
                        <small>add topic details</small>
                    </h1>
                    <ol class="breadcrumb">
                        <li><a href="<?php echo base_url(); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                        <li><a href="<?php echo base_url('index.php/topics'); ?>">Topics</a></li>
                        <li class="active">Add Topic Details</li>
                    </ol>
                </section>

                <!-- Main content -->
                <?php
                foreach ($data as $key) {
                    $title = $key['title'];
                    $assign_id = $key['assign_id'];
                    $fk_topic_id = $key['fk_topic_id'];
                    $fk_user_id = $key['fk_user_id'];
                    $status = $key['status'];
                    $description = $key['description'];
                }
                ?>
                <section class="content">
                    <div class="row">
                        <!-- left column -->
                        <div class="col-md-10">
                            <!-- general form elements -->
                            <div class="box box-primary">
                                <div class="box-header with-border">
                                    <h3 class="box-title">Add Topics Details</h3>
                                </div>
                                <!-- /.box-header -->
                                <!-- form start -->
                                <?php echo form_open('user/submittopic');?>
                                <form role="form" method="POST">
                                    <div class="box-body">
                                        <span class="error-content err ">  <?php
                                            if (!empty($message)) {
                                                echo $message;
                                            }
                                            ?>
                                            <?php echo validation_errors(); ?></span>
                                        <input type="hidden" name="assign_id" value="<?php echo $assign_id; ?>" />
                                        <input  type="hidden" name="fk_topic_id" value="<?php echo $fk_topic_id; ?>"/>
                                        <input type="hidden" name="fk_user_id" value="<?php echo $fk_user_id; ?>" />
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Topic Title</label>
                                            <input type="text" class="form-control" value="<?php echo $title; ?>" readonly="" name="topicTitle" id="exampleInputEmail1" placeholder="Enter topic title">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Description</label>
                                            <textarea rows="5" cols="3"  class="form-control" name="topicDesc" id="exampleInputPassword1" > </textarea>
                                        </div>
                                        <div class="form-group">
                                            <div class="form-group">
                                                <label>Status</label>
                                                <select class="form-control" name="topicStatus">
                                                    <option selected="" value="pending">Pending</option>
                                                </select>
                                            </div>
                                        </div>   

                                    </div>
                                    <!-- /.box-body -->

                                    <div class="box-footer">
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                    </div>
                                </form>
                            </div>
                            <!-- /.box -->

                        </div>
                        <!--/.col (left) -->

                    </div>
                    <!-- /.row -->
                </section>
                <!-- /.content -->
            </div>
            <!-- /.content-wrapper -->


        </div>      
         <!-- jQuery 2.2.3 -->
        <script src="<?php echo base_url(); ?>plugins/jQuery/jquery-2.2.3.min.js"></script>
        <!-- Bootstrap 3.3.6 -->
        <script src="<?php echo base_url(); ?>bootstrap/js/bootstrap.min.js"></script>
        <!-- DataTables -->
        <script src="<?php echo base_url(); ?>plugins/datatables/jquery.dataTables.min.js"></script>
        <script src="<?php echo base_url(); ?>plugins/datatables/dataTables.bootstrap.min.js"></script>
        <!-- SlimScroll -->
        <script src="<?php echo base_url(); ?>plugins/slimScroll/jquery.slimscroll.min.js"></script>
        <!-- FastClick -->
        <script src="<?php echo base_url(); ?>plugins/fastclick/fastclick.js"></script>
        <!-- AdminLTE App -->
        <script src="<?php echo base_url(); ?>dist/js/app.min.js"></script>
        <!-- AdminLTE for demo purposes -->
        <script src="<?php echo base_url(); ?>dist/js/demo.js"></script>
        <!-- page script -->
       
    </body>
</html>

